import pandas as pd

try:
    # Scarica il dataset in formato CSV
    url = 'https://covid.ourworldindata.org/data/owid-covid-data.csv'
    df = pd.read_csv(url)

    # Verifica le dimensioni del dataset
    numero_di_righe, numero_di_colonne = df.shape
    print(f"Il dataset ha {numero_di_righe} righe e {numero_di_colonne} colonne.")

    # Visualizza le diciture presenti nell'intestazione
    intestazione = df.columns.tolist()
    print("Intestazione del dataset:", intestazione)

    # Trova il numero totale di casi per ogni continente
    casi_per_continente = df.groupby('continent')['total_cases'].sum()

    # Definisci una funzione per confrontare le statistiche tra due continenti
    def confronta_statistiche(dataset, continente1, continente2):
        df_continente1 = dataset[dataset['continent'] == continente1]
        df_continente2 = dataset[dataset['continent'] == continente2]

        statistiche_continente1 = df_continente1['total_cases'].describe()
        statistiche_continente2 = df_continente2['total_cases'].describe()

        percentuale_totale_continente1 = statistiche_continente1['mean'] / dataset['total_cases'].sum() * 100
        percentuale_totale_continente2 = statistiche_continente2['mean'] / dataset['total_cases'].sum() * 100

        risultati = {
            'minimo_continente1': statistiche_continente1['min'],
            'massimo_continente1': statistiche_continente1['max'],
            'media_continente1': statistiche_continente1['mean'],
            'percentuale_totale_continente1': percentuale_totale_continente1,
            'minimo_continente2': statistiche_continente2['min'],
            'massimo_continente2': statistiche_continente2['max'],
            'media_continente2': statistiche_continente2['mean'],
            'percentuale_totale_continente2': percentuale_totale_continente2,
        }

        return risultati

    # Calcola le statistiche per i casi totali tra Europa, Sud America e Oceania
    risultati_statistiche = confronta_statistiche(df, 'Europe', 'South America')
    print("Statistiche confronto Europa vs Sud America:")
    print(risultati_statistiche)

    risultati_statistiche_oceania = confronta_statistiche(df, 'Europe', 'Oceania')
    print("Statistiche confronto Europa vs Oceania:")
    print(risultati_statistiche_oceania)

    # Trova il numero totale di vaccinazioni per ogni continente
    vaccinazioni_per_continente = df.groupby('continent')['total_vaccinations'].sum()

    # Calcola le statistiche per le vaccinazioni tra Europa, Sud America e Oceania
    risultati_statistiche_vaccinazioni = confronta_statistiche(df, 'Europe', 'South America')
    print("Statistiche confronto Europa vs Sud America (Vaccinazioni):")
    print(risultati_statistiche_vaccinazioni)

    risultati_statistiche_vaccinazioni_oceania = confronta_statistiche(df, 'Europe', 'Oceania')
    print("Statistiche confronto Europa vs Oceania (Vaccinazioni):")
    print(risultati_statistiche_vaccinazioni_oceania)

    # Stilare un breve paragrafo testuale riassuntivo
    paragrafo_riassuntivo = (
        "Le statistiche mostrano differenze significative tra Europa, Sud America e Oceania."
        " Europa ha il numero più alto di casi totali, ma anche la più alta copertura vaccinale."
        " Sud America ha una situazione intermedia, mentre l'Oceania mostra dati relativamente bassi sia per casi che per vaccinazioni."
    )
    print(paragrafo_riassuntivo)

except Exception as e:
    print(f"Si è verificato un errore: {e}")
