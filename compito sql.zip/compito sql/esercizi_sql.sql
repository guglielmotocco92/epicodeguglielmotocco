-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Set 07, 2023 alle 05:55
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esercizi_sql`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `corsi`
--

CREATE TABLE `corsi` (
  `id_corso` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `data_inizio` date DEFAULT NULL,
  `data_fine` date DEFAULT NULL,
  `costo` int(11) NOT NULL,
  `partecipanti_max` int(11) NOT NULL,
  `id_docente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dump dei dati per la tabella `corsi`
--

INSERT INTO `corsi` (`id_corso`, `nome`, `data_inizio`, `data_fine`, `costo`, `partecipanti_max`, `id_docente`) VALUES
(1, 'Matematica 101', '2023-01-01', '2023-02-01', 100, 9, 1),
(2, 'Matematica 101', '2023-02-02', '2023-03-01', 100, 10, 1),
(3, 'Matematica 101', '2023-03-02', '2023-04-01', 100, 12, 1),
(4, 'Matematica 102', '2022-01-01', '2023-02-01', 100, 12, 1),
(5, 'Matematica 102', '2023-02-01', '2023-03-01', 100, 20, 1),
(6, 'Storia 101', '2023-01-01', '2023-04-01', 120, 13, 9),
(7, 'Biologia 101', '2023-07-09', '2023-08-01', 80, 15, 4),
(8, 'Programmazione 101', '2023-07-01', '2023-08-01', 200, 11, 5),
(9, 'Italiano 101', '2023-07-01', '2023-09-01', 200, 11, 5),
(10, 'Latino 101', '2023-05-01', '2023-06-01', 200, 9, 5),
(11, 'Chimca 101', '2023-01-01', '2023-04-01', 70, 10, 7),
(12, 'Storia 102', '2023-07-09', '2023-08-01', 150, 10, 10),
(13, 'Biologia 102', '2023-07-01', '2023-08-01', 120, 12, 13),
(14, 'Matematica 103', '2023-10-01', '2023-12-01', 100, 15, 1),
(15, 'Matematica 104', '2023-10-01', '2023-11-01', 200, 10, 7);

-- --------------------------------------------------------

--
-- Struttura della tabella `docenti`
--

CREATE TABLE `docenti` (
  `id_docente` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cognome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dump dei dati per la tabella `docenti`
--

INSERT INTO `docenti` (`id_docente`, `nome`, `cognome`, `email`) VALUES
(1, 'Maria', 'Rossi', 'maria.rossi@example.com'),
(2, 'Marco', 'Bianchi', 'marco.bianchi@example.com'),
(3, 'Laura', 'Verdi', 'laura.verdi@example.com'),
(4, 'Luca', 'Esposito', 'luca.esposito@example.com'),
(5, 'Giulia', 'Romano', 'giulia.romano@example.com'),
(6, 'Paolo', 'Conti', 'paolo.conti@example.com'),
(7, 'Anna', 'Gatti', 'anna.gatti@example.com'),
(8, 'Andrea', 'Russo', 'andrea.russo@example.com'),
(9, 'Marta', 'Ferrari', 'marta.ferrari@example.com'),
(10, 'Giovanni', 'Leone', 'giovanni.leone@example.com'),
(11, 'Sofia', 'Moretti', 'sofia.moretti@example.com'),
(12, 'Davide', 'Serra', 'davide.serra@example.com'),
(13, 'Elena', 'Caruso', 'elena.caruso@example.com'),
(14, 'Simone', 'Pellegrini', 'simone.pellegrini@example.com'),
(15, 'Chiara', 'Martino', 'chiara.martino@example.com');

-- --------------------------------------------------------

--
-- Struttura della tabella `studenti`
--

CREATE TABLE `studenti` (
  `id_studente` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cognome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `data_di_nascita` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dump dei dati per la tabella `studenti`
--

INSERT INTO `studenti` (`id_studente`, `nome`, `cognome`, `email`, `data_di_nascita`) VALUES
(1, 'Giovanni', 'Mancini', 'giovanni.mancini@example.com', '1990-03-15'),
(2, 'Elena', 'Martini', 'elena.martini@example.com', '1985-07-21'),
(3, 'Alessandro', 'Rizzo', 'alessandro.rizzo@example.com', '1998-01-02'),
(4, 'Luisa', 'Ferrari', 'luisa.ferrari@example.com', '1992-04-14'),
(5, 'Simone', 'Greco', 'simone.greco@example.com', '1987-09-08'),
(6, 'Sara', 'De Luca', 'sara.deluca@example.com', '1995-06-25'),
(7, 'Francesca', 'Ricci', 'francesca.ricci@example.com', '1983-11-30'),
(8, 'Davide', 'Marino', 'davide.marino@example.com', '1986-12-04'),
(9, 'Laura', 'Santoro', 'laura.santoro@example.com', '1993-05-17'),
(10, 'Andrea', 'Conte', 'andrea.conte@example.com', '1989-10-10'),
(11, 'Alessia', 'Serra', 'alessia.serra@example.com', '1991-08-29'),
(12, 'Giuseppe', 'Mazza', 'giuseppe.mazza@example.com', '1978-03-07'),
(13, 'Martina', 'Bianchi', 'martina.bianchi@example.com', '1982-02-12'),
(14, 'Luigi', 'Galli', 'luigi.galli@example.com', '1997-07-23'),
(15, 'Valentina', 'Marchesi', 'valentina.marchesi@example.com', '1996-09-01'),
(16, 'Paolo', 'Bruno', 'paolo.bruno@example.com', '1984-06-16'),
(17, 'Chiara', 'Rinaldi', 'chiara.rinaldi@example.com', '1994-10-09'),
(18, 'Marco', 'Fabbri', 'marco.fabbri@example.com', '1980-08-18'),
(19, 'Silvia', 'Ferri', 'silvia.ferri@example.com', '1999-04-03'),
(20, 'Marta', 'Lombardi', 'marta.lombardi@example.com', '1981-12-22'),
(21, 'Andrea', 'Rossi', 'andrea.rossi@example.com', '1992-03-27'),
(22, 'Roberto', 'Gentile', 'roberto.gentile@example.com', '1987-05-28'),
(23, 'Giovanna', 'Pellegrini', 'giovanna.pellegrini@example.com', '1986-01-14'),
(24, 'Luca', 'Marconi', 'luca.marconi@example.com', '1998-02-07'),
(25, 'Elisa', 'Colombo', 'elisa.colombo@example.com', '1990-09-11'),
(26, 'Massimo', 'Mariani', 'massimo.mariani@example.com', '1983-04-19'),
(27, 'Sofia', 'Russo', 'sofia.russo@example.com', '1995-11-20'),
(28, 'Antonio', 'Fabbro', 'antonio.fabbro@example.com', '1989-07-26'),
(29, 'Elena', 'Caruso', 'elena.caruso@example.com', '1991-08-02'),
(30, 'Fabio', 'Moretti', 'fabio.moretti@example.com', '1984-10-05'),
(31, 'Giulia', 'Amato', 'giulia.amato@example.com', '1993-06-07'),
(32, 'Dario', 'Longo', 'dario.longo@example.com', '1982-07-09'),
(33, 'Serena', 'Riva', 'serena.riva@example.com', '1997-03-24'),
(34, 'Stefano', 'Barone', 'stefano.barone@example.com', '1980-05-31'),
(35, 'Alice', 'Piras', 'alice.piras@example.com', '1996-09-15'),
(36, 'Riccardo', 'Sanna', 'riccardo.sanna@example.com', '1988-02-03'),
(37, 'Giorgia', 'Coppola', 'giorgia.coppola@example.com', '1994-11-28'),
(38, 'Alessio', 'Mancini', 'alessio.mancini@example.com', '1985-12-17');

-- --------------------------------------------------------

--
-- Struttura della tabella `studenti_corsi`
--

CREATE TABLE `studenti_corsi` (
  `id_iscrizione` int(11) NOT NULL,
  `id_studente` int(11) NOT NULL,
  `id_corso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dump dei dati per la tabella `studenti_corsi`
--

INSERT INTO `studenti_corsi` (`id_iscrizione`, `id_studente`, `id_corso`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 5),
(4, 1, 7),
(5, 1, 10),
(6, 1, 15),
(7, 2, 1),
(8, 2, 5),
(9, 2, 10),
(10, 3, 4),
(11, 4, 1),
(12, 4, 2),
(13, 4, 3),
(14, 4, 8),
(15, 4, 13),
(16, 4, 15),
(17, 5, 2),
(18, 5, 4),
(19, 6, 4),
(20, 6, 10),
(21, 7, 1),
(22, 8, 8),
(23, 9, 10),
(24, 10, 1),
(25, 10, 7),
(26, 10, 9),
(27, 10, 10),
(28, 10, 13),
(29, 11, 10),
(30, 12, 7),
(31, 12, 14),
(32, 13, 4),
(33, 13, 5),
(34, 13, 9),
(35, 14, 2),
(36, 15, 3),
(37, 15, 10),
(38, 16, 3),
(39, 16, 5),
(40, 16, 7),
(41, 16, 12),
(42, 16, 13),
(43, 16, 15),
(44, 17, 11),
(45, 18, 10),
(46, 19, 8),
(47, 20, 5),
(48, 21, 3),
(49, 21, 7),
(50, 22, 6),
(51, 22, 12),
(52, 22, 15),
(53, 23, 6),
(54, 23, 12),
(55, 23, 15),
(56, 24, 4),
(57, 25, 1),
(58, 25, 7),
(59, 25, 8),
(60, 25, 11),
(61, 25, 12),
(62, 26, 4),
(63, 26, 8),
(64, 26, 11),
(65, 27, 3),
(66, 27, 8),
(67, 28, 1),
(68, 29, 2),
(69, 29, 7),
(70, 20, 12),
(71, 29, 13),
(72, 30, 15),
(73, 31, 10),
(74, 32, 4),
(75, 33, 1),
(76, 34, 1),
(77, 34, 7),
(78, 34, 9),
(79, 34, 11),
(80, 35, 3),
(81, 35, 13),
(82, 35, 15),
(83, 36, 2),
(84, 36, 7),
(85, 37, 13),
(86, 38, 11);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `corsi`
--
ALTER TABLE `corsi`
  ADD PRIMARY KEY (`id_corso`);

--
-- Indici per le tabelle `docenti`
--
ALTER TABLE `docenti`
  ADD PRIMARY KEY (`id_docente`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `studenti`
--
ALTER TABLE `studenti`
  ADD PRIMARY KEY (`id_studente`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `studenti_corsi`
--
ALTER TABLE `studenti_corsi`
  ADD PRIMARY KEY (`id_iscrizione`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `corsi`
--
ALTER TABLE `corsi`
  MODIFY `id_corso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT per la tabella `docenti`
--
ALTER TABLE `docenti`
  MODIFY `id_docente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=241;

--
-- AUTO_INCREMENT per la tabella `studenti`
--
ALTER TABLE `studenti`
  MODIFY `id_studente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT per la tabella `studenti_corsi`
--
ALTER TABLE `studenti_corsi`
  MODIFY `id_iscrizione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


